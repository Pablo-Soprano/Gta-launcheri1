package ge.geoliferp.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {

    // ===== SEIZLEBA SHECVALOT =====
    private val SERVER_IP = "188.127.241.74"
    private val SERVER_PORT = 2749
    // tu zusti package gaqvs, chaweret aq (magalitad "com.xxx.yyy"), anu datove carieli
    private val TARGET_PACKAGE = ""
    // tu package carielia, aplikacia moizebneba ase saxelit:
    private val TARGET_LABEL = "Mobile Launcher"
    // ==============================

    private val RED = Color.parseColor("#E10600")
    private val BG = Color.parseColor("#0B0B0B")
    private val CARD = Color.parseColor("#1A1A1A")

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("glrp", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(20), dp(40), dp(20), dp(20))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        root.addView(TextView(this).apply {
            text = "GEO LIFE RP"
            textSize = 30f
            setTextColor(RED)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })

        // statusis baratи
        status = TextView(this).apply {
            text = "Serveri: მოწმდება..."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = round(CARD, 16)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        root.addView(status, lp(top = 28))

        val nick = EditText(this).apply {
            hint = "Name_Surname"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT
            background = round(CARD, 12)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setText(prefs.getString("nick", ""))
        }
        root.addView(nick, lp(top = 16))

        val play = Button(this).apply {
            text = "თამაში"
            textSize = 20f
            setTextColor(Color.WHITE)
            background = round(RED, 14)
            setOnClickListener {
                prefs.edit().putString("nick", nick.text.toString()).apply()
                launchGame()
            }
        }
        root.addView(play, lp(top = 16, h = 60))

        // socialuri gilakebi
        val social = LinearLayout(this).apply { gravity = Gravity.CENTER }
        listOf(
            "Discord" to "https://discord.gg/nFan9PxrtE",
            "Telegram" to "https://t.me/glrpdev",
            "YouTube" to "https://www.youtube.com/@GeoLifeRP",
            "TikTok" to "https://www.tiktok.com/@geoliferp",
            "Facebook" to "https://www.facebook.com/share/g/19PTMZQNPz/",
            "Site" to "https://geoliferp.edgeone.dev/"
        ).forEach { (name, url) ->
            val b = TextView(this).apply {
                text = name.take(2)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                textSize = 13f
                background = round(RED, 24)
                setOnClickListener {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                }
            }
            social.addView(b, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(5), 0, dp(5), 0) })
        }
        root.addView(social, lp(top = 28))

        setContentView(root)
        refreshStatus()
    }

    private fun launchGame() {
        var pkg = TARGET_PACKAGE
        if (pkg.isEmpty()) {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pkg = packageManager.queryIntentActivities(main, 0).firstOrNull {
                it.loadLabel(packageManager).toString().contains(TARGET_LABEL, true)
            }?.activityInfo?.packageName ?: ""
        }
        val i = if (pkg.isNotEmpty()) packageManager.getLaunchIntentForPackage(pkg) else null
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } else {
            Toast.makeText(this, "$TARGET_LABEL არ არის დაინსტალებული", Toast.LENGTH_LONG).show()
        }
    }

    // SA-MP query (UDP) - realuri online da players
    private fun refreshStatus() {
        Thread {
            var text = "Serveri: OFFLINE"
            try {
                val ip = InetAddress.getByName(SERVER_IP)
                val pkt = "SAMP".toByteArray() + ip.address +
                        byteArrayOf((SERVER_PORT and 0xFF).toByte(), ((SERVER_PORT shr 8) and 0xFF).toByte(), 'i'.code.toByte())
                DatagramSocket().use { s ->
                    s.soTimeout = 2500
                    s.send(DatagramPacket(pkt, pkt.size, ip, SERVER_PORT))
                    val buf = ByteArray(512)
                    val resp = DatagramPacket(buf, buf.size)
                    s.receive(resp)
                    val bb = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN)
                    val players = bb.getShort(12).toInt() and 0xFFFF
                    val max = bb.getShort(14).toInt() and 0xFFFF
                    text = "Serveri: ONLINE   $players/$max"
                }
            } catch (_: Exception) {}
            runOnUiThread { status.text = text }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(top: Int = 0, h: Int = LinearLayout.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            if (h > 0) dp(h) else h
        ).apply { topMargin = dp(top) }
}
