1) GitHub-ze axali repo sheqmeni, ამ zip-is shigtavsi ატვირთე (.github foldertan ertad).
2) Actions -> Build APK -> Run workflow.
3) 2-4 wutshi Artifacts-shi chamoitvirte GeoLifeRP-Launcher-APK (app-debug.apk).
MainActivity.kt-shi TARGET_PACKAGE-ze chaweret Mobile Launcher-is package saxeli.
